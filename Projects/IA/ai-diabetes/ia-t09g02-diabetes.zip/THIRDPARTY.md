# [dataset.csv](dataset.csv)
- Source: https://www.kaggle.com/datasets/marshalpatel3558/diabetes-prediction-dataset-legit-dataset
